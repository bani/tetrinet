extern char *keystr (int id);
