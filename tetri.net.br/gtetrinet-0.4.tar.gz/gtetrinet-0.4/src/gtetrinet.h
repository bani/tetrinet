#define APPID PACKAGE
#define APPNAME "GTetrinet"
#define APPVERSION VERSION

void destroymain (GtkWidget *widget, gpointer data);
