/* Tetrinet for Linux, by Andy Church <achurch@dragonfire.net>
 * This program may be freely distributed.
 *
 * Socket routine declarations.
 */

#ifndef SOCKETS_H
#define SOCKETS_H

extern int sgetc(int s);
extern int sungetc(int c, int s);
extern char *sgets(char *buf, int len, int s);
extern int sputs(const char *buf, int len);
extern int sockprintf(int s, const char *fmt, ...);
extern int conn(const char *host, int port);
extern void disconn(int s);
extern void get_remote_ip(int s, char retbuf[4]);

#endif	/* SOCKETS_H */
