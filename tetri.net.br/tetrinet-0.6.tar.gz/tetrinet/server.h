#ifndef SERVER_H
#define SERVER_H

extern void read_config(void);
extern void write_config(void);
extern int server_main(void);

#endif	/* SERVER_H */
