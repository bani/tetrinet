DdP Theme 3.0
-------------------------------------
[http://www.geocities.com/ddpclan]

Decompacte usando o Winzip no diret�rio do TetriNet,
Ir� criar um diret�rio [DdP], depois � s� selecionar
o ddp.tnp no tetrinet em <misc settings>. Ap�s isso,
� s� divertir-se :)

-------------------------------------

Problemas?!
Under[DdP]
ralph@infocenter.com.br