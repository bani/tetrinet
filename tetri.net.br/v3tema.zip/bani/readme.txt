* Tema para TetriNet 1.13 *
design: Vanessa
e-mail: vanessa@starplace.com

Recomendo que voc� leia as instru��es antes de instalar o tema.
Elas s�o encontradas na p�gina http://tetrinetbr.cjb.net